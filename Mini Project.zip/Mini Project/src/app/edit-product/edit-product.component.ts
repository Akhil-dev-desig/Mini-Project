import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductsService } from '../services/products.service';
import { Product } from '../model/product.model';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;
  product: Product;
  productId: string;
  constructor(private formBuilder: FormBuilder, private router: Router,
    private route: ActivatedRoute,
    private productService: ProductsService) {
    this.route.params.subscribe(params => this.productId = params['id']);
    console.log(this.productId);
  }
  //logOff Product
  logOutProduct(): void {
    if (localStorage.getItem("username") != null) {
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }
  ngOnInit() {
    // if (localStorage.getItem(username) != null) {
    //   let productId = localStorage.getItem('editProductId')
    if (this.productId != null) {
      if (!this.productId) {
        // alert('Invalid Action');

        this.router.navigate(['list-product']);
        return;
      }
      this.editForm = this.formBuilder.group({
        _id: [this.productId],
        prodid: ['', Validators.required],
        custName: ['', [Validators.required, Validators.pattern("[A-Z][a-z]{2,29}")]],
        prodName: ['', Validators.required],
        description: ['', Validators.required],
        price: ['', Validators.required,],
        quantity: ['', Validators.required]

      });

      //pulling data from database using service
      //this.productService.getProductsById(+productId)
      this.productService.getProductsById(this.productId).subscribe(data => {
        this.editForm.setValue(data)
      });
    }
    else {
      this.router.navigate(['/login']);
    }
  }//end of ngOnInit() function

  onSubmit() {
    this.submitted = true;
    if (this.editForm.invalid) {
      Swal.fire({
        type: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
        footer: '<a href>Why do I have this issue?</a>'
      })

      return;
    }

    this.productService.updateProduct(this.editForm.value)
      //.pipe(first())
      .subscribe(data => {
        Swal.fire({
          position: 'center',
          type: 'success',
          title: 'Your work has been saved',
          showConfirmButton: false,
          timer: 1500
        })
        this.router.navigate(['list-product']);
      }, error => {
        alert(error);
      });

  }

}
