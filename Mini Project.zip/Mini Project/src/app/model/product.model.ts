export class Product {
  id: any;
  _id: string;
  custName: string;
  prodName: string;
  address: string;
  //photo:string;
  price: number;
  quantity: number;
  //instock: boolean;
}