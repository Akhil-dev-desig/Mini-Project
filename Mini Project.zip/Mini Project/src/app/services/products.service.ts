import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../model/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http: HttpClient) { }
  // baseUrl:string = "http://localhost:3000/products";
  baseUrl: string = "http://localhost:8090/api/products";

  //Get All Produts
  getProducts() {
    return this.http.get<Product[]>(this.baseUrl);
  }
  //Get Products By Id
  getProductsById(_id: string) {
    return this.http.get<Product>(this.baseUrl + "/" + _id);
  }
  //Add Product
  createProduct(product: Product) {
    return this.http.post(this.baseUrl, product);
  }
  //Modify Product
  updateProduct(product: Product) {
    return this.http.put(this.baseUrl + '/' + product._id, product);
  }
  //Delete Product By Id
  deleteProduct(id: string) {
    return this.http.delete(this.baseUrl + '/' + id);
  }
}


