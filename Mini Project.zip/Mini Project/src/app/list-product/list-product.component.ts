import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product.model';
import { Router } from '@angular/router';
import { ProductsService } from '../services/Products.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-list-product',
  templateUrl: './list-product.component.html',
  styleUrls: ['./list-product.component.css']
})
export class ListProductComponent implements OnInit {
  //creating an Array of Product class
  products: Product[];
  //filtering by name
  searchText: any;

  //constructor dependency Injection
  constructor(private router: Router, private productService: ProductsService) { }

  //logOff Product
  logOutProduct(): void {
    if (localStorage.getItem("username") != null) {
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }

  //Delete Product
  deleteProduct(product: Product): void {
    let result = (Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    }));
    if (result) {
      this.productService.deleteProduct(product._id)
        .subscribe(data => {
          this.products = this.products.filter
            (p => p !== product);
        })
      // alert(`${product.custName} record is deleted..!`);
      // window.location.reload();
    }
  }

  //Modify Product
  editProduct(product: Product): void {

    this.router.navigate(['edit-product', product._id.toString()]);
  }
  //Add New Product
  addProduct(): void {
    this.router.navigate(['add-product']);
  }


  //loading all users as soon as component gets loaded
  ngOnInit() {

    if (localStorage.getItem("username") != null) {
      this.productService.getProducts()
        .subscribe(data => {
          this.products = data;
        });
    }
    else {
      this.router.navigate(['/login']);
    }
  }

}
