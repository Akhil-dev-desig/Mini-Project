// Step1: Importing all predefined modules
var express = require("express");
var cors = require("cors");
var mongoose = require("mongoose");
var bodyParser = require("body-parser");
var fs = require('fs');
var morgan = require('morgan');
var path = require('path');
// Importing userdefined model
var Product = require('./models/product.model');

// Creating app object to start server
var app = express();

// Step2: Configure View engine is optional here

// Step3: Connect Your Mongodb - mongodb url
mongoose.connect('mongodb://localhost:27017/products', { useNewUrlParser: true });

// Step4: Configure Middleware
// parse requests of encoding-type-application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
// parse requests of content-type - application/json 
app.use(bodyParser.json());

// Step5: Define routes
// create router object to create userfriendly urls
// routes logic will come here
var router = express.Router();

// create a write stream(in append mode)
// MOrgan lOgging
var accessLogStream =
    fs.createWriteStream(path.join(__dirname, 'access.log'), { flags: 'a' });

// setup the logger
app.use(morgan('combined', { stream: accessLogStream }))

// using Middlewares
// Mount Route Path - executed for each request
router.use(function (req, res, next) {
    //do logging

    // Manual Login
    // if (req.method == "GET")
    //    accessLogStream.write(req.method + ' ' + req.url + ' All users are or User is retrieved at ' + new Date());
    // else if (req.method == "POST")
    //     accessLogStream.write(req.method + ' ' + req.url + 'New User has been ADDED ' + new Date() + '\n');
    // else if (req.method == "PUT")
    //     accessLogStream.write(req.method + ' ' + req.url + 'User has been MODIFIED at ' + new Date() + '\n');
    // else if (req.method == "DELETE")
    //     accessLogStream.write(req.method + ' ' + req.url + 'User has been DELETED at ' + new Date() + '\n');

    //do authentication
    console.log('Logging of request will be done here');
    // make sure we go to the next routes and don't stop here
    next();
});

// Create
router.route('/products').post(function (req, res) {
    var product = new Product();
    product.prodid = req.body.prodid;
    product.custName = req.body.custName;
    product.prodName = req.body.prodName;
    product.description = req.body.description;
    product.price = req.body.price;

    product.quantity = req.body.quantity;

    product.save(function (err) {
        if (err) {
            res.send(err.stack);
            return;
        }
        console.log("added")
        res.send({ message: 'Product Created' })
    });
});

// read
router.route('/products').get(function (req, res) {
    Product.find(function (err, products) {
        if (err) {
            res.send(err.stack);
            return;
        }
        res.send(products);
    });
});

// get by Id
router.route('/products/:id').get(function (req, res) {
    Product.findById(req.params.id, { __v: 0 }, function (err, product) {
        if (err) {
            res.send(err.stack);
            return;
        }
        res.json(product);
    });
});

// update
router.route('/products/:id').put(function (req, res) {
    Product.findById(req.params.id, function (err, product) {
        if (err) {
            res.send(err.stack);
            return;
        }
        product.prodid = req.body.prodid;
        product.custName = req.body.custName;
        product.prodName = req.body.prodName;
        product.description = req.body.description;
        product.price = req.body.price;

        product.quantity = req.body.quantity;

        product.save(function (err) {
            if (err) {
                res.send(err.stack);
                return;
            }
            res.json({ message: 'Product updated!' });
        });
    });
});

// delete
router.route('/products/:id').delete(function (req, res) {
    Product.remove({ _id: req.params.id }, function (err, product) {
        if (err) {
            res.send(err.stack);
            return;
        }
        res.json({ message: 'Product successfully deleted' });
    });
});

// User.findByIdAndRemove({ _id: req.params.id}, (err, user)=> {
// if(err)
// res.json(err);
// else
// res.json('Removed successfully');
// })

// middlewares
app.use(cors());
app.use('/api', router);
app.listen(8090);

console.log('REST API is running at 8090');